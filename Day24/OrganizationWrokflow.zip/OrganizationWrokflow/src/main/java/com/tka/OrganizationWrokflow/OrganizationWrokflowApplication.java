package com.tka.OrganizationWrokflow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrganizationWrokflowApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrganizationWrokflowApplication.class, args);
		System.out.println("Application Started...");
	}

}
