package com.tka.OrganizationWrokflow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrganizationWrokflowApplicationTests {

	@Test
	void contextLoads() {
	}

}
